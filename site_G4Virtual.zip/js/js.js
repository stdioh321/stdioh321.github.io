	
$(document).ready(function() {
      $('.flexslider').flexslider({
        animation: "slide"
      });

   //    $( "img:not(.slides img)" ).each(function( index ) {
	  // });
	  
});
