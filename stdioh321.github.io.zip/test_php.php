<?php
		header('Access-Control-Allow-Origin: *');
		
		echo "Ola Mundo...";

?>